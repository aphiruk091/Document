﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tranning_Result
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Gridview_props();

        }
        public void Gridview_props()
        {
            this.dataGridView1.DataSource = Data();


            dataGridView1.Columns[1].Width = 800;
            dataGridView1.Columns[2].Visible = false;
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "ใช่";
            checkBoxColumn.Width = 50;
            checkBoxColumn.Name = "checkBoxColumn1";
            dataGridView1.Columns.Insert(3, checkBoxColumn);
            DataGridViewCheckBoxColumn checkBoxColumn2 = new DataGridViewCheckBoxColumn();
            checkBoxColumn2.HeaderText = "ไม่ใช่";
            checkBoxColumn2.Width = 50;
            checkBoxColumn2.Name = "checkBoxColumn2";
            dataGridView1.Columns.Insert(4, checkBoxColumn2);

        }
        public DataTable Data()
        {
            string Fulltext = ""; ;
            string FileSaveWithPath = @"C:\Traning\Traning.txt";
            string filePath = FileSaveWithPath;
            DataTable dtCsv = new DataTable();
            using (StreamReader sr = new StreamReader(FileSaveWithPath, Encoding.UTF8, true))
            {
                while (!sr.EndOfStream)
                {
                    //ข้อ,ประโยคคำถาม,เฉลย,ใช่,ไม่ใช่
                    //byte[] utf = System.Text.Encoding.UTF8.GetBytes(pMPC_GROUP);
                    //pMPC_GROUP = System.Text.Encoding.UTF8.GetString(utf);
                    Fulltext = sr.ReadToEnd().ToString(); //read full file text  
                    string Fulltext2 = Fulltext.ToString().Replace("\"", " ").Replace(System.Environment.NewLine, "\a");
                    string[] rows = Fulltext2.Split('\a');
                    for (int i = 0; i < rows.Count() - 1; i++)
                    {


                        if (i == 0)
                        {
                            string columnName = "ข้อ,ประโยคคำถาม,เฉลย";

                            string[] ColumnName = columnName.Split(',');
                            for (int j = 0; j < ColumnName.Count(); j++)
                            {
                                dtCsv.Columns.Add(ColumnName[j]); //add headers  
                            }
                        }

                        string[] rowValues = rows[i].Split(','); //split each row with comma to get individual values  
                        {
                            DataRow dr = dtCsv.NewRow();
                            for (int k = 0; k < rowValues.Count(); k++)
                            {
                                try
                                {
                                    dr[k] = rowValues[k].ToString();
                                }
                                catch
                                {

                                }
                            }
                            dtCsv.Rows.Add(dr); //add other rows  

                        }
                    }//for
                }
            }//using

            return dtCsv;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int count_chk = 0;
            for (int i = 0; i < 20; i++)
            {
                string check = string.Empty;
                string choice = string.Empty;
                bool isSelected1 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn1"].Value);
                bool isSelected2 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn2"].Value);
                choice = dataGridView1.Rows[i].Cells["เฉลย"].Value.ToString();
                if (isSelected1)
                {
                    check = "Y";
                    count_chk = count_chk + 1;
                }
                if (isSelected2)
                {
                    check = "N";
                    count_chk = count_chk + 1;
                }
                
            }
            if (count_chk == 20)
            {
                submit();
            }
            else
            {
                MessageBox.Show("กรุณาเลือกให้ครบ 20 ข้อ");
            }

        }
        public void submit()
        {

            int answer = 0;
            int unanswer = 0;
            int count_chk = 0;
            for (int i = 0; i < 20; i++)
            {
                string check = string.Empty;
                string choice = string.Empty;
                bool isSelected1 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn1"].Value);
                bool isSelected2 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn2"].Value);
                choice = dataGridView1.Rows[i].Cells["เฉลย"].Value.ToString();
                if (isSelected1)
                {
                    check = "Y";
                    count_chk = count_chk + 1;
                }
                if (isSelected2)
                {
                    check = "N";
                    count_chk = count_chk + 1;
                }
                if (check == choice)
                {
                    answer = answer + 1;
                }
                else
                {
                    unanswer = unanswer + 1;
                }
            }
            string result = myMessageBox.ShowBox(answer.ToString() + "  คะแนน");
            if (result == "1")
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
            //MessageBox.Show("Answer  ถูก : " + answer.ToString() + "  ผิด" + unanswer.ToString());
        }
        
        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            int choicecheck = 0;
            for (int i = 0; i < 20; i++)
            {
                string check = string.Empty;
                string choice = string.Empty;
               
                bool isSelected1 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn1"].Value);
                bool isSelected2 = Convert.ToBoolean(dataGridView1.Rows[i].Cells["checkBoxColumn2"].Value);
                if (isSelected1)
                {
                    check = "Y";
                    dataGridView1.Rows[i].Cells["checkBoxColumn2"].ReadOnly = true;
               
                }
                else
                {
                    dataGridView1.Rows[i].Cells["checkBoxColumn2"].ReadOnly = false;
                 
                }
                if (isSelected2)
                {
                    check = "N";
                    dataGridView1.Rows[i].Cells["checkBoxColumn1"].ReadOnly = true;

                }
                else
                {
                  
                    dataGridView1.Rows[i].Cells["checkBoxColumn1"].ReadOnly = false;
                   
                }
                
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Close();
            this.Close();
        }
    }
}
