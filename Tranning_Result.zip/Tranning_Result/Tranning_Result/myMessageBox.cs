﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tranning_Result
{
    public partial class myMessageBox : Form
    {
        static myMessageBox newMessageBox;
        static string Button_ID;
        public myMessageBox()
        {
            InitializeComponent();
        }
        public static string ShowBox(string txtMessage)
        {
            newMessageBox = new myMessageBox();
            newMessageBox.label2.Text = txtMessage;
            newMessageBox.ShowDialog();
            Button_ID = "1";
            return Button_ID;
        }
    }
}
